const StatsSection = () => {
  return null;
};

export default StatsSection;
